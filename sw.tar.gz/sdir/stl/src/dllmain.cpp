// Copyright (c) Microsoft Corporation.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

#include <internal_shared.h>

#include <Windows.h>

extern "C" BOOL APIENTRY DllMain(HMODULE, DWORD, LPVOID) noexcept {
    return TRUE;
}
